<?Php
//***************************************
// This is downloaded from www.plus2net.com //
// You can distribute this code with the link to www.plus2net.com ///
// Please don't  remove the link to www.plus2net.com ///
// This is for your learning only not for commercial use. ///////
// The author is not responsible for any type of loss or problem or damage on using this script.//
// You can use it at your own risk. /////
//*****************************************
?>


<!doctype html public "-//w3c//dtd html 3.2//en">

<html>

<head>
<title>plus2net calendar</title>
</head>

<body >

<form method=post action='' name=f1>
<table border=0 cellpadding=0 cellspacing=0 width=900> <tr>
<td ><font size=2 face='Verdana'>Enter you date</font><input type=text name='p_name' size='8'> <a href="javascript:void(0);" NAME="plus2net Calendar" title=" plus2net Calendar " onClick=window.open("cal2.php","Ratting","width=350,height=270,left=150,top=200,toolbar=1,status=1,");>Click here to open the calendar window</a>  | <a href="javascript:void(0);" NAME="plus2net Calendar" title=" plus2net Calendar " onClick=window.open("cal3.php","Ratting","width=350,height=270,left=150,top=200,toolbar=1,status=1,");>week  starting on Monday</a> 
</td></tr> </table></form> 


</body>

</html>
