This is downloaded from www.plus2net.com 
You can distribute this code with the link to www.plus2net.com 
Please don't  remove the link to www.plus2net.com 
This is for your learning only not for commercial use. 
The author is not responsible for any type of loss or problem or damage on using this script.
You can use it at your own risk.

This is for your learning only, not to be used for spamming or for any commercial uses. 

Read the instructions at www.plus2net.com  php section and post your query/bugs at the forum at plus2net.com. 

Visit http://www.plus2net.com/php_tutorial/php_calendar.php  for script updates and more details. 

If your week starts from Monday then use cal3.php file inplace of cal2.php 
For yearly calendar with Monday as week start day then use year-calendar3.php file