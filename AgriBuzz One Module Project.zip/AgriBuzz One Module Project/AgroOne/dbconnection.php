<?php
//error_reporting(0);
// Create connection
$con=mysqli_connect("localhost","root","","agroone");
echo mysqli_connect_error();
?>