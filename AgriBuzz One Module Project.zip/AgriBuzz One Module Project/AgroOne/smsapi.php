<?php
$smsstatus="Disabled";
$smsapi = "sdfjakjfjsldfhsdkfhgi";
$senderid = "AGRIBUZ";
/*
customer purchase request
farmer approval for request
customer payment notification

worker hire
worker job
*/
?>